BloodRaw font created by Woowz11

Original font location: https://github.com/Woowz11/woowzsite/blob/main/BloodRaw/Source/minecraft.ttf